require 'test_helper'

class GoalsHelperTest < ActionView::TestCase
end
